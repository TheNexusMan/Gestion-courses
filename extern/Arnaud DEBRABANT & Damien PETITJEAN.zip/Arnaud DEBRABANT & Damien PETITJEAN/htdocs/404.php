<!-- Arnaud DEBRABANT P1707147 - Damien PETITJEAN P1408987 -->
<?php
    session_start();
    include "includes/header.php";
?>

<div class="container">
    <div class="row">
        <h1 class="mx-auto">Erreur 404 : Page introuvable</h1>
        <img class="mx-auto" src="data/404.jpg" alt="404"/>
    </div>
</div>

<?php include "includes/footer.php";?>